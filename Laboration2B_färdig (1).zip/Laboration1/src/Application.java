import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/**
 * Application class responsible for main method and initializing objects and programme
 */

abstract class Application {

    public static void main(String[] args) {


        CarModel cm = new CarModel();


        cm.cars.add(VehicleFactory.createVolvo240());


        CarController cc = new CarController(cm);

        CarView frame = new CarView("Arrecool SwimmingPool",cc, cm);
        cc.addObserver(frame);


        // Start the timer
        cc.timer.start();
    }
}
