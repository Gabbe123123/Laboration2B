import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/*
 * This class represents the Controller part in the MVC pattern.
 * It's responsibilities is to listen to the View and responds in a appropriate manner by
 * modifying the model state and the updating the view.
 */

//Observer

public class CarController {
    // member fields:
// The delay (ms) corresponds to 20 updates a sec (hz)
    private final int delay = 50;
    // The timer is started with an listener (see below) that executes the statements
    // each step between delays.
    public Timer timer = new Timer(delay, new TimerListener());

    // The frame that represents this instance View of the MVC pattern
    //CarView frame;
     //Få bort med observer pattern
    //private class Listener implements observer, men bara om man har tid
    // A list of cars, modify if needed

    CarModel model;

    private ArrayList<Observer1> observers = new ArrayList(); //List of observers to notify

//Contructor
    public CarController(CarModel model) {
        this.model=model;
    }


    /* Each step the TimerListener moves all the cars in the list and tells the
     * view to update its images. Change this method to your needs.
     * */

    private class TimerListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            for (Vehicle car : model.cars) {
                car.move(1);
                if (car instanceof Scania) {
                    System.out.println(((Scania) car).getPlatformAngle());
                    //speedMonitor.updatePrintedSpeed();
                }
                if (!carOutOfBounds(car)) {
                    notifyObservers();

                }

                if (carOutOfBounds(car)) {
                    car.stopEngine();
                    car.turnLeft();
                    car.turnLeft();
                    car.startEngine();
                }
            }
        }
    }

    //methods:

    /**
     * Method to notify observers as part of the observer pattern implementation
     */

    public void notifyObservers() {
        for (Observer1 o : observers)
            o.actOnUpdate();
    }

    /**
     * Method to add an observer to the observer list
     * @param o, the observer to be added
     */

    public void addObserver(Observer1 o) {
        observers.add(o);
    }

    public boolean carOutOfBounds(Vehicle car) {
        if(car.getXCoordinate()-car.getCurrentSpeed()<0 || car.getXCoordinate()+car.getCurrentSpeed()>=700) {
            return true;
        }
        return false;
    }


    /**
     * Method to stop all cars
     */

    void stopAllCars() {
        for(Vehicle car: model.cars) {
            car.stopEngine();
        }
    }

    /**
     * Method to start all cars
     */

    void startAllCars() {
        for(Vehicle car: model.cars) {
            car.startEngine();
        }
    }

    /**
     * Method to turn turboOn, only applicable for Saab95
     */

    void turboOn() {
        for(Vehicle car : model.cars) {
            if(car instanceof Saab95) {
                ((Saab95) car).setTurboOn();
            }
        }
    }

    /**
     * Method to lift bed, only applicable for Scania
     */
    void liftBed() {
        for(Vehicle car : model.cars) {
            if(car instanceof Scania) {
                ((Scania) car).tilt(10);
            }

        }

    }

    /**
     * Method to lower bed, only applicable for Scania
     */
    void lowerLiftBed() {
        for(Vehicle car : model.cars) {
            if(car instanceof Scania) {
                ((Scania) car).tilt(-10);
            }

        }

    }
    /**
     * Method to set turboOff, only applicable for saab
     */
    void turboOff() {
        for(Vehicle car : model.cars) {
            if(car instanceof Saab95) {
                ((Saab95) car).setTurboOff();
            }
        }
    }
    // Calls the gas method for each car once

    /**
     * Method to increase speed
     */

    void gas(int amount) {
        double gas = ((double) amount) / 100;
        for (Vehicle car : model.cars
        ) {
            car.gas(gas);

        }
    }

    /**
     * Method to break the car, applicable for all cars
     */
    void brake(int amount) {
        double brake = ((double) amount) / 100;
        for (Vehicle car : model.cars
        ) {
            car.brake(brake);
        }
    }
}
