import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * The model representation of the program, handles logic, designed so that it's not dependent on views or controllers
 */

public class CarModel {


    ArrayList<Vehicle> cars = new ArrayList<Vehicle>(); //The list of cars

    /**
     * Method to remove car from list, only has an effect if list contains a/several cars
     */

    public void removeCar() {
        if(cars.size()>0)
        cars.remove(cars.size()-1);
    }

    /**
     * Method to add car to list, only gets added if list contains less than 10 cars
     * Selects random car
     */

    public void addCar() {
        if(cars.size()<=10)

    {
        double x = 10 * Math.random();
        if (x <= 3) {
            cars.add(VehicleFactory.createVolvo240());
        }
        if (x <= 6 && x>3) {
            cars.add(VehicleFactory.createSaab95());
        }

        if (x > 6) {
            cars.add(VehicleFactory.createScania());

        }
    }
    }
}


