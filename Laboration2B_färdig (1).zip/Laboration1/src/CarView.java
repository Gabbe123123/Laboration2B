import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

//Är detta en observable? När användare klickar på knappar ska man notifiera panelen som är observer
//CarView observer på CarController

/**
 * This class represents the full view of the MVC pattern of your car simulator.
 * It initializes with being center on the screen and attaching it's controller in it's state.
 * It communicates with the Controller by calling methods of it when an action fires of in
 * each of it's components.
 * TODO: Write more actionListeners and wire the rest of the buttons
 **/

public class CarView extends JFrame implements Observer1{
    private static final int X = 800;
    private static final int Y = 800;

    // The controller member
    CarController carC; //Få bort med observer

    CarModel model;
    DrawPanel drawPanel;

    JPanel controlPanel = new JPanel();

    SpeedMonitor speed;

    JPanel gasPanel = new JPanel();
    JSpinner gasSpinner = new JSpinner();
    int gasAmount = 0;
    int brakeAmount=1;
    JLabel gasLabel = new JLabel("Amount of gas");

    JButton gasButton = new JButton("Gas");
    JButton brakeButton = new JButton("Brake");
    JButton turboOnButton = new JButton("Saab Turbo on");
    JButton turboOffButton = new JButton("Saab Turbo off");
    JButton liftBedButton = new JButton("Scania Lift Bed");
    JButton lowerBedButton = new JButton("Lower Lift Bed");
    JButton addCarButton = new JButton("Add new car");
    JButton removeCarButton = new JButton("Remove a car");

    JButton startButton = new JButton("Start all cars");
    JButton stopButton = new JButton("Stop all cars");

    // Constructor
    public CarView(String framename, CarController cc, CarModel model){
        this.model=model;
        drawPanel= new DrawPanel(X, Y-240,model);
        this.carC = cc;
        speed=new SpeedMonitor(model);
        initComponents(framename);

    }

    /**
     * Updates the graphics when the observer gets notified
     *
     */


    public void actOnUpdate() {
        drawPanel.repaint();
    }


    // Sets everything in place and fits everything
    // TODO: Take a good look and make sure you understand how these methods and components work

    /**
     *
     *
     * @param title
     * Adds the components to the panel, connects the speedMonitor
     */
    private void initComponents(String title) {

        this.setTitle(title);
        this.setPreferredSize(new Dimension(X,Y));
        this.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
        this.add(speed);
        this.add(drawPanel);



        SpinnerModel spinnerModel =
                new SpinnerNumberModel(0, //initial value
                        0, //min
                        100, //max
                        1);//step
        gasSpinner = new JSpinner(spinnerModel);
        gasSpinner.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent e) {
                gasAmount = (int) ((JSpinner)e.getSource()).getValue();
            }


        });

        gasPanel.setLayout(new BorderLayout());
        gasPanel.add(gasLabel, BorderLayout.PAGE_START);
        gasPanel.add(gasSpinner, BorderLayout.PAGE_END);

        this.add(gasPanel);

        controlPanel.setLayout(new GridLayout(2,4));

        controlPanel.add(gasButton, 0);
        controlPanel.add(turboOnButton, 1);
        controlPanel.add(liftBedButton, 2);
        controlPanel.add(brakeButton, 3);
        controlPanel.add(turboOffButton, 4);
        controlPanel.add(lowerBedButton, 5);
        controlPanel.add(addCarButton, 6);
        controlPanel.add(removeCarButton, 7);
        controlPanel.setPreferredSize(new Dimension((X/2)+4, 200));
        this.add(controlPanel);
        controlPanel.setBackground(Color.CYAN);


        startButton.setBackground(Color.blue);
        startButton.setForeground(Color.green);
        startButton.setPreferredSize(new Dimension(X/5-15,200));
        this.add(startButton);


        stopButton.setBackground(Color.red);
        stopButton.setForeground(Color.black);
        stopButton.setPreferredSize(new Dimension(X/5-15,200));
        this.add(stopButton);

        // This actionListener is for the gas button only
        // TODO: Create more for each component as necessary


        /**
         * If the addCarbutton is pressed then a new car is added with a method in carModel
         */


        addCarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.addCar();
            }
        });

        /**
         * If the removeCarButton is pressed then the last car in the list gets removed
         */

        removeCarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                model.removeCar();
            }
        });

        /**
         * If the startButton is pressed then startAllCars method in carController is used
         */
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carC.startAllCars();
            }
        });
        /**
         * If the stopButton is pressed then startAllCars method in carController is used
         */

        stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carC.stopAllCars();
            }
        });

        /**
         * If the gasButton is pressed then gas method in carController is used
         */

        gasButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carC.gas(gasAmount);
            }
        });

        /**
         * If the liftBedButton is pressed then liftBed method in carController is used
         */
        liftBedButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carC.liftBed();
            }
        });


        /**
         * If the lowerBedButton is pressed then lowerLiftBed method in carController is used
         */

        lowerBedButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carC.lowerLiftBed();
            }
        });

        /**
         * If the brakeButton is pressed then brake method in carController is used
         */
        brakeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carC.brake(gasAmount);
            }
        });

        /**
         * If the turboOnButton is pressed then turboOn method in carController is used
         */

        turboOnButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carC.turboOn();
            }
        });

        /**
         * If the turboOffButton is pressed then turboOff method in carController is used
         */

        turboOffButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                carC.turboOff();
            }
        });


        // Make the frame pack all it's components by respecting the sizes if possible.
        this.pack();

        // Get the computer screen resolution
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        // Center the frame
        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
        // Make the frame visible
        this.setVisible(true);
        // Make sure the frame exits when "x" is pressed
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    /*@Override
    public void registerObserver(ViewObserver o) {
this.viewObserverList.add(o);
    }

    @Override
    public void removeObserver(ViewObserver o) {
        this.viewObserverList.remove(o);
    }

    @Override
    public void notifyObservers() {
        for(ViewObserver o: viewObserverList){
            o.actOnBreakButton();
            o.actOnGasButton();
            o.actOnLiftBedButton();
            o.actOnLowerBedButton();
            o.actOnStartButton();
            o.actOnStopButton();
            o.actOnTurboOffButton();
            o.actOnTurboOnButton();
        }

     */

    }


