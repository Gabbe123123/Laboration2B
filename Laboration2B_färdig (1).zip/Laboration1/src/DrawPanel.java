import java.awt.*;
import java.io.IOException;
import javax.swing.*;

//Kan detta som som en observer?

// This panel represent the animated part of the view with the car images.

public class DrawPanel extends JPanel {


    CarModel model;


    // Initializes the panel and reads the images

    /**
     * A model is needed in order to paint the components
     * @param x
     * @param y
     * @param model
     */
    public DrawPanel(int x, int y, CarModel model) {
        this.model = model;
        this.setDoubleBuffered(true);
        this.setPreferredSize(new Dimension(x, y));
        this.setBackground(Color.green);

    }

    // This method is called each time the panel updates/refreshes/repaints itself
    // TODO: Change to suit your needs.
    @Override
    /**
     * Paints a car with the getImage method in carModel,each added car will be 100 below the previous car on the y axis
     */
    protected void paintComponent(Graphics g) {
        int i =0;
        super.paintComponent(g);
        for (Vehicle car : model.cars) {
                try {
                    g.drawImage(car.getImage(), (int) car.getXCoordinate(), (int) car.getYCoordinate()+i*100, null); // see javadoc for more info on the parameters
                } catch (IOException e) {
                    e.printStackTrace();
                }
            i++;

             }


        }
    }
