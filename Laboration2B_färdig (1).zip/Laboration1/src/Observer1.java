/**
 * Observer interface
 * Removed CarController's dependency on CarView (CarView is now an observer that gets notified)
 */
public interface Observer1 {
    void actOnUpdate();
}
