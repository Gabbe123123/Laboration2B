import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 * Class Scania which inherits from Vehicle and implements the interface tiltable
 */

public class Scania extends Vehicle implements Tiltable {


    private double platformAngle; //The angle of the platform
    private BufferedImage scaniaImage;


    /**
     * Constructor for a Scania
     */

    public Scania() {
        super(2, Color.white, "Scania", 770, 0, 0, 0, 0, 5, 1.5);
        platformAngle = 0;
    }

    /**
     * Speedfactor for a Scania
     * @return 1, because a Scania has no speed factor
     */

    @Override
    public double speedFactor() {
        return 1;
    }

    /**
     * Method to tilt platform, if platform angle is more than 0, the car stops.
     * Platform angle can only be changed if current speed is 0.
     * If someone tries to set a negative angle, the angle sets at 0.
     * If someone tries to set an angle > 70, the angle sets at max value 70.
     * @param changePlatformAngle, value to change angle with
     */

    public BufferedImage getImage() throws IOException {


            scaniaImage = ImageIO.read(DrawPanel.class.getResourceAsStream("pics/Scania.jpg"));

        return scaniaImage;
    }

    @Override
    public void tilt(double changePlatformAngle) {



        if (platformAngle > 0) {
            setCurrentSpeed(0);
        }
        if (getCurrentSpeed() == 0) {

            if ((platformAngle + changePlatformAngle) < 0) {
                platformAngle = 0;
            }

            if ((platformAngle + changePlatformAngle) >= 70) {
                platformAngle = 70;
            }
            if((platformAngle + changePlatformAngle) >= 0 && (platformAngle + changePlatformAngle)<70) {
                platformAngle += changePlatformAngle;
            }
        }
    }


    /**
     * Method to move a car for a certain time period, makes sure car cannot move if the platform has an angle
     * @param time, the time of the movement in seconds
     */

@Override
    public void move(double time) {

if (platformAngle!=0){
    setCurrentSpeed(0);
}

    else {
        super.move(time);
    }
}
public double getPlatformAngle(){
    return platformAngle;
}
}