import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * SpeedMonitor class, to keep track of the cars' speeds
 * Is added in CarView
 */

public class SpeedMonitor extends JPanel implements ActionListener{
JLabel labelScania; JButton GetSpeedbutton;
    JLabel labelSaab;
    JLabel labelVolvo;
    CarModel model;

    public SpeedMonitor(CarModel model) {
        this.model=model;
        labelScania = new JLabel();
        labelVolvo = new JLabel();
        labelSaab= new JLabel();
        labelScania.setBounds(1, 0, 250, 20);
        labelSaab.setBounds(1, 25, 250, 20);
        labelVolvo.setBounds(1, 50, 250, 20);
        GetSpeedbutton=new JButton("Get current speed");
        GetSpeedbutton.addActionListener(this);
            add(GetSpeedbutton);
            add(labelScania);
        add(labelVolvo);
        add(labelSaab);

        GetSpeedbutton.setBounds(10,100,150,30);
        setSize(100, 100);
           // setLayout(null);
            setVisible(true);
            }

    /**
     * Goes through all cars and prints out each speed once "Get current speed" button is clicked
     * @param e
     */

    @Override
    public void actionPerformed(ActionEvent e) {
        for (Vehicle car : model.cars) {

            try {
                if(car instanceof Scania)
                    labelScania.setText(("Speed for: " + car.getModelName() + " is: " + car.getCurrentSpeed()));
                if(car instanceof Saab95)
                    labelSaab.setText(("Speed for: " + car.getModelName() + " is: " + car.getCurrentSpeed()));
                if(car instanceof Volvo240)
                    labelVolvo.setText(("Speed for: " + car.getModelName() + " is: " + car.getCurrentSpeed()));

            } catch (Exception ex) {
                System.out.println(ex);
            }
        }




    }
}

