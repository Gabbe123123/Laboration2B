public interface Tiltable {

void tilt(double ChangePlatformAngle);

}
